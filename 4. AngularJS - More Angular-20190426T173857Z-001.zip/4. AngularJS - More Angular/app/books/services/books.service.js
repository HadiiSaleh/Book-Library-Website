booksModule.service('booksService', ['$http', function ($http) {

	this.getBooks = function () {
		return $http.get('/books');
	};

	this.getBook = function (id) {
		return $http.get('/books/' + id);
	};

	this.newBook = function (book) {
		return $http.post('/books', book);
	};

	this.deleteBook = function (id) {
		return $http.delete('/books/' + id)
	};
}]);