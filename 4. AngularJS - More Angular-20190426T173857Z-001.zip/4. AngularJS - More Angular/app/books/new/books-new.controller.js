booksModule.controller('newBookCtrl', ['$scope', 'booksService', '$location', function ($scope, booksService, $location) {
	$scope.newBook = {};

	$scope.addBook = function () {
		booksService.newBook($scope.newBook).then(function () {
			$location.path('/books');
		});
	};
}]);