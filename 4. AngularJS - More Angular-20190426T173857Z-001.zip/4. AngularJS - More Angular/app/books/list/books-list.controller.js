booksModule.controller('booksCtrl', ['$scope', 'booksService', function ($scope, booksService) {

	$scope.search = {
		name: ''
	};

	$scope.books = [];

	booksService.getBooks().then(function (response) {
		$scope.books = response.data;
	});

	$scope.deleteBook = function (book) {
		booksService.deleteBook(book.id).then(function () {
			var idx = $scope.books.indexOf(book);
			if (idx >= 0) {
				$scope.books.splice(idx, 1);
			}
		});
	};
}]);