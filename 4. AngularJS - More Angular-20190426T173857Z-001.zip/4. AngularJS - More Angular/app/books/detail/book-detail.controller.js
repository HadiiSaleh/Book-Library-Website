booksModule.controller('bookDetailCtrl', ['$scope', 'booksService', '$routeParams', function ($scope, booksService, $routeParam) {
	$scope.book = {};
	booksService.getBook($routeParam.bookId).then(function (response) {
		var book = response.data;
		$scope.book = book;
	});
}]);