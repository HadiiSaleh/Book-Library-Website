var app = angular.module('myApp', ['ngRoute', 'booksModule', 'authorsModule']);

app.config(['$routeProvider', function ($routeProvider) {
	$routeProvider
		.when('/books', {
			templateUrl: './app/books/list/books-list.template.html',
			controller: 'booksCtrl'
		})
		.when('/books/new', {
			templateUrl: './app/books/new/books-new.template.html',
			controller: 'newBookCtrl'
		})
		.when('/books/:bookId', {
			templateUrl: './app/books/detail/book-detail.template.html',
			controller: 'bookDetailCtrl'
		})
		.otherwise('/books');
}]);