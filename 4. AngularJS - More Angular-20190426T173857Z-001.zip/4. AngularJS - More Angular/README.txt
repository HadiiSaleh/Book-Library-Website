How to run the project:

1. Install node.js from https://nodejs.org/en/
2. In the command line (cmd or bash), navigate to this project folder using `cd` command and keep the command line window opened
	e.g. cd "c:\Users\YourUserName\Desktop\Workshop\Live coding sessions\2. JS"
3. In the same command line window, run: npm install
4. In the same command line window, run: npm start (do not close the command line window unless you want to stop the project)
5. Go to http://localhost:3000 to browse the project